create
    definer = ssg@localhost procedure customer_level_case(IN customer_id_input int)
begin
    declare customer_level varchar(10);
    declare amount_sum float;

    set amount_sum = (
        select sum(amount)
        from payment
        where customer_id = customer_id_input
        group by customer_id
        );

    case
        when amount_sum >= 150 then set customer_level = 'vvip';
        when amount_sum >= 120 then set customer_level = 'vip';
        when amount_sum >= 100 then set customer_level = 'gold';
        when amount_sum >= 80 then set customer_level = 'silver';
        else set customer_level = 'bronze';
    end case;

    select customer_id_input as customer_id, amount_sum, customer_level;
end;

