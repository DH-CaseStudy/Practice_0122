create definer = root@localhost view customer_list as
select `cu`.`customer_id`                                       AS `ID`,
       concat(`cu`.`first_name`, _utf8mb4' ', `cu`.`last_name`) AS `name`,
       `a`.`address`                                            AS `address`,
       `a`.`postal_code`                                        AS `zip code`,
       `a`.`phone`                                              AS `phone`,
       `city`.`city`                                            AS `city`,
       `country`.`country`                                      AS `country`,
       if(`cu`.`active`, _utf8mb4'active', _utf8mb4'')          AS `notes`,
       `cu`.`store_id`                                          AS `SID`
from (((`customer` `cu` join `address` `a` on ((`cu`.`address_id` = `a`.`address_id`))) join `city`
       on ((`a`.`city_id` = `city`.`city_id`))) join `country` on ((`city`.`country_id` = `country`.`country_id`)));

