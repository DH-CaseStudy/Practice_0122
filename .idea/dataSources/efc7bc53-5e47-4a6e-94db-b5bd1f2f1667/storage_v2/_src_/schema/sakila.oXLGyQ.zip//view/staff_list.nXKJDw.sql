create definer = root@localhost view staff_list as
select `s`.`staff_id`                                         AS `ID`,
       concat(`s`.`first_name`, _utf8mb4' ', `s`.`last_name`) AS `name`,
       `a`.`address`                                          AS `address`,
       `a`.`postal_code`                                      AS `zip code`,
       `a`.`phone`                                            AS `phone`,
       `city`.`city`                                          AS `city`,
       `country`.`country`                                    AS `country`,
       `s`.`store_id`                                         AS `SID`
from (((`staff` `s` join `address` `a` on ((`s`.`address_id` = `a`.`address_id`))) join `city`
       on ((`a`.`city_id` = `city`.`city_id`))) join `country` on ((`city`.`country_id` = `country`.`country_id`)));

