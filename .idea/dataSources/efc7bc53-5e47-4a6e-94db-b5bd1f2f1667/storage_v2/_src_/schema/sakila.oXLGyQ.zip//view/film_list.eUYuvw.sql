create definer = root@localhost view film_list as
select `film`.`film_id`                                                                            AS `FID`,
       `film`.`title`                                                                              AS `title`,
       `film`.`description`                                                                        AS `description`,
       `category`.`name`                                                                           AS `category`,
       `film`.`rental_rate`                                                                        AS `price`,
       `film`.`length`                                                                             AS `length`,
       `film`.`rating`                                                                             AS `rating`,
       group_concat(concat(`actor`.`first_name`, _utf8mb4' ', `actor`.`last_name`) separator ', ') AS `actors`
from ((((`film` left join `film_category` on ((`film_category`.`film_id` = `film`.`film_id`))) left join `category`
        on ((`category`.`category_id` = `film_category`.`category_id`))) left join `film_actor`
       on ((`film`.`film_id` = `film_actor`.`film_id`))) left join `actor`
      on ((`film_actor`.`actor_id` = `actor`.`actor_id`)))
group by `film`.`film_id`, `category`.`name`;

